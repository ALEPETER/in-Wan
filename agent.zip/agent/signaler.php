<?php
session_start();
if(!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'agent') {
    header('Location: ../index.php');
    exit();
}
require_once '../config/database.php';

$error = '';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $equipement = $_POST['equipement'];
    $type_panne = $_POST['type_panne'];
    $description = $_POST['description'];
    $urgence = $_POST['urgence'];
    $agent_id = $_SESSION['user_id'];
    
    if(empty($equipement) || empty($type_panne) || empty($description)) {
        $error = "Tous les champs sont obligatoires";
    } else {
        $stmt = $conn->prepare("INSERT INTO signalements (agent_id, equipement, type_panne, description, urgence, statut) VALUES (?, ?, ?, ?, ?, 'en_attente')");
        if($stmt->execute([$agent_id, $equipement, $type_panne, $description, $urgence])) {
            $signalement_id = $conn->lastInsertId();
            header("Location: upload.php?id=" . $signalement_id);
            exit();
        } else {
            $error = "Erreur lors de l'enregistrement";
        }
    }
}

$date_jour = date('d/m/Y');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nouveau signalement - IN WAN</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#1e3a8a',
                        primaryLight: '#3b82f6',
                        success: '#10b981',
                        warning: '#f97316',
                        danger: '#ef4444',
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-gradient-to-br from-slate-900 to-primary min-h-screen p-6">
    <div class="w-full max-w-4xl mx-auto">
        <div class="bg-white rounded-2xl shadow-xl p-8">
            
            <!-- En-tête -->
            <div class="flex justify-between items-center mb-6 pb-4 border-b border-gray-100">
                <div class="flex items-center gap-3">
                    <img src="../assets/images/logo.jpg" alt="IN WAN" class="h-10 w-auto">
                    <div>
                        <div class="font-semibold text-gray-800 text-base"><?php echo htmlspecialchars($_SESSION['user_nom']); ?></div>
                        <div class="text-xs text-gray-400"><?php echo $date_jour; ?></div>
                    </div>
                </div>
                <a href="dashboard.php" class="bg-gray-100 text-gray-600 px-4 py-2 rounded-full text-sm hover:bg-gray-200 transition">← Retour</a>
            </div>
            
            <!-- Étapes -->
            <div class="flex gap-3 mb-8">
                <div class="flex-1 bg-primary text-white text-center py-2 rounded-full text-sm font-semibold">1. Informations</div>
                <div class="flex-1 bg-gray-200 text-gray-500 text-center py-2 rounded-full text-sm">2. Preuves</div>
                <div class="flex-1 bg-gray-200 text-gray-500 text-center py-2 rounded-full text-sm">3. Confirmation</div>
            </div>
            
            <h2 class="text-2xl font-bold text-gray-800 mb-2">Nouveau signalement</h2>
            <p class="text-sm text-gray-500 mb-6">Décrivez la panne pour une intervention rapide</p>
            
            <?php if($error): ?>
                <div class="bg-red-50 text-danger p-4 rounded-xl mb-6 text-sm border-l-4 border-danger"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <form method="POST">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div class="mb-4">
                        <label class="block text-gray-700 font-semibold text-sm mb-2">🏭 Équipement concerné *</label>
                        <select name="equipement" required class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20">
                            <option value="">Sélectionnez un équipement</option>
                            <option value="Machine à emballer 3000">Machine à emballer 3000</option>
                            <option value="Convoyeur 2">Convoyeur 2</option>
                            <option value="Pompe à eau">Pompe à eau</option>
                            <option value="Compresseur">Compresseur</option>
                            <option value="Presse hydraulique">Presse hydraulique</option>
                            <option value="Système de ventilation">Système de ventilation</option>
                            <option value="Table de convoyage">Table de convoyage</option>
                        </select>
                    </div>
                    
                    <div class="mb-4">
                        <label class="block text-gray-700 font-semibold text-sm mb-2">⚡ Type de panne *</label>
                        <select name="type_panne" required class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20">
                            <option value="">Sélectionnez le type</option>
                            <option value="Électrique">Électrique</option>
                            <option value="Mécanique">Mécanique</option>
                            <option value="Hydraulique">Hydraulique</option>
                            <option value="Pneumatique">Pneumatique</option>
                            <option value="Logiciel">Logiciel</option>
                            <option value="Structurel">Structurel</option>
                        </select>
                    </div>
                </div>
                
                <div class="mb-5">
                    <label class="block text-gray-700 font-semibold text-sm mb-2">📝 Description détaillée *</label>
                    <textarea name="description" rows="6" required class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20" placeholder="Décrivez le problème en détail..."></textarea>
                </div>
                
                <div class="mb-6">
                    <label class="block text-gray-700 font-semibold text-sm mb-3">🔥 Niveau d'urgence *</label>
                    <div class="flex gap-6 flex-wrap">
                        <label class="flex items-center gap-2 px-4 py-2 bg-green-50 rounded-xl cursor-pointer hover:bg-green-100 transition">
                            <input type="radio" name="urgence" value="faible" checked class="w-4 h-4 text-success"> 
                            <span class="text-sm font-medium text-green-700">🟢 Faible</span>
                        </label>
                        <label class="flex items-center gap-2 px-4 py-2 bg-orange-50 rounded-xl cursor-pointer hover:bg-orange-100 transition">
                            <input type="radio" name="urgence" value="moyen" class="w-4 h-4 text-warning"> 
                            <span class="text-sm font-medium text-orange-700">🟡 Moyen</span>
                        </label>
                        <label class="flex items-center gap-2 px-4 py-2 bg-blue-50 rounded-xl cursor-pointer hover:bg-blue-100 transition">
                            <input type="radio" name="urgence" value="urgent" class="w-4 h-4 text-primary"> 
                            <span class="text-sm font-medium text-blue-700">🔵 Urgent</span>
                        </label>
                        <label class="flex items-center gap-2 px-4 py-2 bg-red-50 rounded-xl cursor-pointer hover:bg-red-100 transition">
                            <input type="radio" name="urgence" value="critique" class="w-4 h-4 text-danger"> 
                            <span class="text-sm font-medium text-red-700">🔴 Critique</span>
                        </label>
                    </div>
                </div>
                
                <button type="submit" class="w-full bg-primary text-white font-semibold py-4 rounded-xl hover:bg-primaryLight transition transform hover:-translate-y-0.5 text-lg">
                    Étape suivante → Ajouter des preuves
                </button>
            </form>
        </div>
    </div>
</body>
</html>