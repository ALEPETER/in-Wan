<?php
session_start();
if(!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'agent') {
    header('Location: ../index.php');
    exit();
}
require_once '../config/database.php';

$agent_id = $_SESSION['user_id'];

$stmt = $conn->prepare("SELECT COUNT(*) as total FROM signalements WHERE agent_id = ?");
$stmt->execute([$agent_id]);
$total = $stmt->fetch()['total'];

$stmt = $conn->prepare("SELECT COUNT(*) as encours FROM signalements WHERE agent_id = ? AND statut IN ('en_attente','valide','affecte','en_cours')");
$stmt->execute([$agent_id]);
$encours = $stmt->fetch()['encours'];

$stmt = $conn->prepare("SELECT COUNT(*) as termines FROM signalements WHERE agent_id = ? AND statut = 'termine'");
$stmt->execute([$agent_id]);
$termines = $stmt->fetch()['termines'];

$stmt = $conn->prepare("SELECT * FROM signalements WHERE agent_id = ? ORDER BY date_signalement DESC LIMIT 10");
$stmt->execute([$agent_id]);
$signalements = $stmt->fetchAll();

$date_jour = date('d/m/Y');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Agent - IN WAN</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#1e3a8a',
                        primaryLight: '#3b82f6',
                        success: '#10b981',
                        warning: '#f97316',
                        danger: '#ef4444',
                    }
                }
            }
        }
    </script>
    <style>
        body {
            background: linear-gradient(135deg, #0f172a 0%, #1e3a8a 100%);
            min-height: 100vh;
            padding: 30px;
        }
        .dashboard-container {
            max-width: 1400px;
            margin: 0 auto;
        }
        .stat-card {
            transition: transform 0.2s;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        .signalement-item {
            transition: all 0.2s;
        }
        .signalement-item:hover {
            transform: translateX(5px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Carte principale -->
        <div class="bg-white rounded-3xl shadow-xl overflow-hidden">
            
            <!-- En-tête -->
            <div class="bg-primary px-8 py-5 flex justify-between items-center">
                <div class="flex items-center gap-4">
                    <img src="../assets/images/logo.jpg" alt="IN WAN" class="w-8 h-auto object-contain">
                    <div>
                        <div class="font-semibold text-white text-xl"><?php echo htmlspecialchars($_SESSION['user_nom']); ?></div>
                        <div class="text-white/70 text-sm"><?php echo $date_jour; ?></div>
                    </div>
                </div>
                <a href="../logout.php" class="bg-white/20 text-white px-5 py-2 rounded-full text-sm hover:bg-white/30 transition">Déconnexion</a>
            </div>
            
            <!-- Contenu -->
            <div class="p-8">
                <!-- Statistiques -->
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                    <div class="stat-card bg-blue-50 rounded-2xl p-6 text-center border-l-4 border-primary">
                        <div class="text-sm text-gray-500 uppercase font-semibold mb-2">Total signalements</div>
                        <div class="text-4xl font-bold text-primary"><?php echo $total; ?></div>
                    </div>
                    <div class="stat-card bg-orange-50 rounded-2xl p-6 text-center border-l-4 border-warning">
                        <div class="text-sm text-gray-500 uppercase font-semibold mb-2">En cours</div>
                        <div class="text-4xl font-bold text-warning"><?php echo $encours; ?></div>
                    </div>
                    <div class="stat-card bg-green-50 rounded-2xl p-6 text-center border-l-4 border-success">
                        <div class="text-sm text-gray-500 uppercase font-semibold mb-2">Terminés</div>
                        <div class="text-4xl font-bold text-success"><?php echo $termines; ?></div>
                    </div>
                </div>
                
                <!-- Bouton Nouveau signalement -->
                <a href="signaler.php" 
                   class="block bg-primary text-white text-center font-semibold py-4 rounded-xl mb-8 hover:bg-primaryLight transition transform hover:-translate-y-0.5 text-lg">
                    ➕ NOUVEAU SIGNALEMENT
                </a>
                
                <!-- Liste des signalements -->
                <div class="flex justify-between items-center mb-4">
                    <h3 class="font-bold text-gray-800 text-xl">📋 Mes signalements récents</h3>
                    <span class="text-sm text-gray-400">Total : <?php echo count($signalements); ?></span>
                </div>
                
                <?php if(count($signalements) > 0): ?>
                    <div class="space-y-3">
                        <?php foreach($signalements as $s): ?>
                            <div class="signalement-item bg-gray-50 rounded-xl p-4 border border-gray-100">
                                <div class="flex justify-between items-center flex-wrap gap-4">
                                    <div class="flex-1">
                                        <div class="font-semibold text-gray-800 text-base">#<?php echo $s['id']; ?> - <?php echo htmlspecialchars($s['equipement']); ?></div>
                                        <div class="text-sm text-gray-500 mt-1">
                                            <?php echo htmlspecialchars($s['type_panne']); ?> • 
                                            <?php echo date('d/m/Y à H:i', strtotime($s['date_signalement'])); ?>
                                        </div>
                                    </div>
                                    <div class="flex items-center gap-3">
                                        <?php if($s['statut'] == 'termine'): ?>
                                            <span class="px-3 py-1 rounded-full text-xs font-semibold bg-green-100 text-success">✅ Terminé</span>
                                        <?php elseif($s['statut'] == 'en_cours'): ?>
                                            <span class="px-3 py-1 rounded-full text-xs font-semibold bg-orange-100 text-warning">🔧 En cours</span>
                                        <?php else: ?>
                                            <span class="px-3 py-1 rounded-full text-xs font-semibold bg-blue-100 text-primary">⏳ En attente</span>
                                        <?php endif; ?>
                                        <a href="detail.php?id=<?php echo $s['id']; ?>" class="bg-primary text-white px-4 py-2 rounded-full text-sm hover:bg-primaryLight transition">Voir détails</a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="bg-gray-50 rounded-xl p-8 text-center text-gray-400">
                        🚫 Aucun signalement pour le moment
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>