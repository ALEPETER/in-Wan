<?php
session_start();
if(!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'agent') {
    header('Location: ../index.php');
    exit();
}
require_once '../config/database.php';

$signalement_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if($signalement_id <= 0) {
    header('Location: dashboard.php');
    exit();
}

$stmt = $conn->prepare("SELECT * FROM signalements WHERE id = ? AND agent_id = ?");
$stmt->execute([$signalement_id, $_SESSION['user_id']]);
$signalement = $stmt->fetch();
if(!$signalement) {
    header('Location: dashboard.php');
    exit();
}

$message = '';
$error = '';

if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['media'])) {
    $upload_dir = '../uploads/';
    if(!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
    
    $file = $_FILES['media'];
    $filename = time() . '_' . basename($file['name']);
    $target = $upload_dir . $filename;
    
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    $type_media = in_array($ext, ['jpg','jpeg','png','gif']) ? 'photo' : (in_array($ext, ['mp4','mov','avi']) ? 'video' : '');
    
    if($type_media) {
        if(move_uploaded_file($file['tmp_name'], $target)) {
            $stmt = $conn->prepare("INSERT INTO photos (signalement_id, chemin_photo, type_media) VALUES (?, ?, ?)");
            $stmt->execute([$signalement_id, $target, $type_media]);
            $message = "Fichier ajouté avec succès !";
        } else {
            $error = "Erreur lors de l'upload.";
        }
    } else {
        $error = "Format non supporté (jpg, png, mp4, ...)";
    }
}

$stmt = $conn->prepare("SELECT * FROM photos WHERE signalement_id = ?");
$stmt->execute([$signalement_id]);
$medias = $stmt->fetchAll();

$date_jour = date('d/m/Y');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter des preuves - IN WAN</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <style>
        * {
            font-family: 'Inter', sans-serif;
        }
        body {
            background: linear-gradient(135deg, #0f172a 0%, #1e3a8a 100%);
            min-height: 100vh;
            padding: 24px;
        }
        .glass-card {
            background: white;
            border-radius: 32px;
            box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25);
            overflow: hidden;
        }
        .btn-primary {
            background: linear-gradient(135deg, #1e3a8a, #2563eb);
            transition: all 0.2s;
        }
        .btn-primary:hover {
            background: linear-gradient(135deg, #2563eb, #3b82f6);
            transform: translateY(-2px);
            box-shadow: 0 10px 20px -5px rgba(37,99,235,0.4);
        }
        .file-input-wrapper {
            flex: 1;
        }
        .file-input-wrapper input {
            width: 100%;
            padding: 12px;
            border: 1px solid #e2e8f0;
            border-radius: 16px;
            transition: all 0.2s;
        }
        .file-input-wrapper input:focus {
            outline: none;
            border-color: #1e3a8a;
            box-shadow: 0 0 0 3px rgba(30,58,138,0.1);
        }
    </style>
</head>
<body>
    <div class="max-w-4xl mx-auto">
        <div class="glass-card">
            <!-- En-tête -->
            <div class="bg-gradient-to-r from-[#1e3a8a] to-[#2563eb] px-8 py-4 flex justify-between items-center">
                <div class="flex items-center gap-3">
                    <div class="bg-white rounded-xl p-1">
                        <img src="../assets/images/logo.jpg" alt="IN WAN" class="h-8 w-auto">
                    </div>
                    <h2 class="text-white font-bold">Ajouter des preuves</h2>
                </div>
                <a href="dashboard.php" class="bg-white/20 hover:bg-white/30 text-white px-4 py-1 rounded-full text-sm">← Retour</a>
            </div>
            
            <div class="p-8">
                <!-- Étapes -->
                <div class="flex items-center justify-between mb-8">
                    <div class="flex items-center gap-3">
                        <div class="w-8 h-8 bg-green-600 text-white rounded-full flex items-center justify-center text-sm font-bold">✓</div>
                        <span class="font-medium text-gray-700">Informations</span>
                    </div>
                    <div class="h-px flex-1 bg-blue-200 mx-3"></div>
                    <div class="flex items-center gap-3">
                        <div class="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-bold">2</div>
                        <span class="font-medium text-gray-700">Preuves</span>
                    </div>
                    <div class="h-px flex-1 bg-gray-200 mx-3"></div>
                    <div class="flex items-center gap-3">
                        <div class="w-8 h-8 bg-gray-200 text-gray-400 rounded-full flex items-center justify-center text-sm font-bold">3</div>
                        <span class="text-gray-400">Confirmation</span>
                    </div>
                </div>
                
                <h1 class="text-2xl font-bold text-gray-800 mb-2">Ajoutez des photos ou vidéos</h1>
                <p class="text-gray-500 mb-6">Ces preuves aideront l'équipe technique à diagnostiquer rapidement la panne.</p>
                
                <?php if($message): ?>
                    <div class="bg-green-50 text-green-700 p-4 rounded-xl mb-6 border-l-4 border-green-500"><?php echo $message; ?></div>
                <?php endif; ?>
                <?php if($error): ?>
                    <div class="bg-red-50 text-red-600 p-4 rounded-xl mb-6 border-l-4 border-red-500"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <!-- Formulaire d'upload avec flex côte à côte -->
                <form method="POST" enctype="multipart/form-data">
                    <div class="border-2 border-dashed border-gray-300 rounded-xl p-6 text-center mb-6 hover:border-blue-500 transition">
                        <div class="flex flex-col sm:flex-row gap-4 items-center justify-center">
                            <!-- Champ fichier -->
                            <div class="file-input-wrapper w-full sm:w-auto">
                                <input type="file" name="media" accept="image/*,video/*" class="w-full">
                            </div>
                            <!-- Bouton ajouter -->
                            <button type="submit" class="btn-primary text-white px-6 py-3 rounded-xl text-sm font-medium whitespace-nowrap">
                                📎 Ajouter ce fichier
                            </button>
                        </div>
                        <p class="text-xs text-gray-400 mt-4">Formats acceptés : JPG, PNG, GIF, MP4, MOV</p>
                    </div>
                </form>
                
                <!-- Galerie des fichiers ajoutés -->
                <?php if(count($medias) > 0): ?>
                    <h3 class="font-semibold text-gray-700 mb-3">📸 Fichiers ajoutés (<?php echo count($medias); ?>)</h3>
                    <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 mb-6">
                        <?php foreach($medias as $m): ?>
                            <div class="bg-gray-100 rounded-xl overflow-hidden aspect-square relative group">
                                <?php if($m['type_media'] == 'photo'): ?>
                                    <img src="<?php echo $m['chemin_photo']; ?>" class="w-full h-full object-cover">
                                <?php else: ?>
                                    <video src="<?php echo $m['chemin_photo']; ?>" class="w-full h-full object-cover"></video>
                                <?php endif; ?>
                                <div class="absolute top-1 right-1 bg-red-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs opacity-0 group-hover:opacity-100 transition cursor-pointer" onclick="return confirm('Supprimer ce fichier ?')">✕</div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="bg-gray-50 rounded-xl p-6 text-center text-gray-400 mb-6">
                        📭 Aucun fichier ajouté pour l'instant
                    </div>
                <?php endif; ?>
                
                <!-- Boutons de navigation -->
                <div class="flex flex-col sm:flex-row gap-4">
                    <a href="signaler.php" class="flex-1 bg-gray-200 text-gray-700 text-center py-3 rounded-xl hover:bg-gray-300 transition">← Modifier le signalement</a>
                    <a href="confirmation.php?id=<?php echo $signalement_id; ?>" class="flex-1 btn-primary text-white text-center py-3 rounded-xl">Terminer et envoyer ✓</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>