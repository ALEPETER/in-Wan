<?php
session_start();
if(!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'chef_equipe') {
    header('Location: ../index.php');
    exit();
}
require_once '../config/database.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$action = isset($_GET['action']) ? $_GET['action'] : '';

if($id && $action) {
    if($action == 'valider') {
        $stmt = $conn->prepare("UPDATE signalements SET statut = 'valide_chef', date_validation_chef = NOW() WHERE id = ?");
        $stmt->execute([$id]);
    } elseif($action == 'refuser') {
        $stmt = $conn->prepare("UPDATE signalements SET statut = 'refuse_chef' WHERE id = ?");
        $stmt->execute([$id]);
    }
}
header('Location: dashboard.php');
exit();
?>